<?php 
echo "Primer texto para el proyecto prueba automatización 1";

?>
